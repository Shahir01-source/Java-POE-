import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Represents a chat message and its validation, lifecycle, and storage.
 *
 * Part 3 adds five arrays that are filled by the program while it runs (nothing
 * is hard-coded): sent messages, disregarded messages, stored messages, message
 * hashes and message IDs. The stored messages array is read back in from the
 * JSON file, and the operations behind the "Stored Messages" menu work on
 * these arrays.
 *
 * The arrays are ArrayLists (resizable arrays) because the number of messages
 * is not known in advance.
 */
public class Message {

    private static final Path DEFAULT_STORAGE_FILE = Path.of("storedMessages.json");

    private static int messageCounter = 0;
    private static int totalMessagesSent = 0;
    private static Path storageFile = DEFAULT_STORAGE_FILE;
    private static String currentSender = "Unknown sender";

    // ---------- The five Part 3 arrays ----------
    private static final ArrayList<Message> sentMessages = new ArrayList<>();
    private static final ArrayList<Message> disregardedMessages = new ArrayList<>();
    private static final ArrayList<Message> storedMessages = new ArrayList<>();
    private static final ArrayList<String> messageHashes = new ArrayList<>();
    private static final ArrayList<String> messageIds = new ArrayList<>();

    private final String messageId;
    private final int messageNumber;
    private final String sender;
    private final String recipient;
    private final String messageText;
    private final String messageHash;
    private String status;

    public Message(String recipient, String messageText) {
        this(generateMessageId(), messageCounter++, currentSender, recipient, messageText);
    }

    private Message(String messageId, int messageNumber, String sender,
                    String recipient, String messageText) {
        this.messageId = messageId;
        this.messageNumber = messageNumber;
        this.sender = sender;
        this.recipient = recipient;
        this.messageText = messageText;
        this.messageHash = createMessageHash(messageId, messageNumber, messageText);
        this.status = "Pending";
    }

    /**
     * Builds a message with a chosen message ID and no recipient validation.
     * Only the developer test data uses this (the brief's "Developer" entry
     * has an ID the program would never generate and a recipient number
     * without an international code). The normal app flow uses the
     * constructor above.
     */
    public static Message developerMessage(String messageId, String recipient, String messageText) {
        return new Message(messageId, messageCounter++, currentSender, recipient, messageText);
    }

    // ---------- Part 1 / Part 2 methods ----------

    public static String generateMessageId() {
        Random random = new Random();
        StringBuilder id = new StringBuilder();
        for (int i = 0; i < 10; i++) {
            id.append(random.nextInt(10));
        }
        return id.toString();
    }

    public static Boolean checkMessageID(String id) {
        return id != null && id.length() <= 10;
    }

    public static String checkRecipientCell(String cellNumber) {
        boolean valid = new Login().checkCellPhoneNumber(cellNumber);
        if (valid) {
            return "Cell phone number successfully captured.";
        }
        return "Cell phone number is incorrectly formatted or does not contain "
                + "an international code. Please correct the number and try again.";
    }

    public static String checkMessageLength(String messageText) {
        if (messageText == null) {
            return "Message cannot be null.";
        }
        if (messageText.length() <= 250) {
            return "Message ready to send.";
        }
        int over = messageText.length() - 250;
        return "Message exceeds 250 characters by " + over + "; please reduce the size.";
    }

    public static String createMessageHash(String messageId, int messageNumber, String messageText) {
        String idPrefix = messageId.substring(0, Math.min(2, messageId.length()));
        String[] words = messageText.trim().split("\\s+");
        String firstWord = stripPunctuation(words[0]).toUpperCase();
        String lastWord = stripPunctuation(words[words.length - 1]).toUpperCase();
        return idPrefix + ":" + messageNumber + ":" + firstWord + lastWord;
    }

    private static String stripPunctuation(String word) {
        return word.replaceAll("[^a-zA-Z0-9]", "");
    }

    /**
     * Handles the user's choice for this message: 1 = send, 2 = disregard,
     * 3 = store. Each choice now also puts the message into the matching array,
     * and every processed message has its hash and ID added to the hash and ID
     * arrays.
     */
    public String sentMessage(int choice) {
        if (!"Pending".equals(status)) {
            return "Message has already been processed.";
        }
        switch (choice) {
            case 1:
                status = "Sent";
                totalMessagesSent++;
                sentMessages.add(this);
                recordHashAndId();
                return "Message successfully sent.";
            case 2:
                status = "Disregarded";
                disregardedMessages.add(this);
                recordHashAndId();
                return "Press 0 to delete the message.";
            case 3:
                status = "Stored";
                storedMessages.add(this);
                recordHashAndId();
                storeMessage();
                return "Message successfully stored.";
            default:
                return "Invalid option selected.";
        }
    }

    private void recordHashAndId() {
        messageHashes.add(messageHash);
        messageIds.add(messageId);
    }

    public static String printMessages() {
        if (sentMessages.isEmpty()) {
            return "No messages have been sent yet.";
        }
        StringBuilder output = new StringBuilder();
        for (Message message : sentMessages) {
            output.append(describe(message));
        }
        return output.toString();
    }

    public static int returnTotalMessages() {
        return totalMessagesSent;
    }

    // ---------- JSON storage: writing ----------

    /**
     * Writes every message in the stored messages array out to the JSON file.
     * The whole file is rewritten from the array each time, which keeps the
     * JSON valid (this is also how a deleted message disappears from the file).
     */
    public void storeMessage() {
        writeStoredMessagesToFile();
    }

    private static void writeStoredMessagesToFile() {
        StringBuilder json = new StringBuilder("[\n");
        for (int i = 0; i < storedMessages.size(); i++) {
            Message message = storedMessages.get(i);
            json.append("  {\n")
                    .append("    \"messageId\": \"").append(escape(message.messageId)).append("\",\n")
                    .append("    \"messageHash\": \"").append(escape(message.messageHash)).append("\",\n")
                    .append("    \"sender\": \"").append(escape(message.sender)).append("\",\n")
                    .append("    \"recipient\": \"").append(escape(message.recipient)).append("\",\n")
                    .append("    \"message\": \"").append(escape(message.messageText)).append("\"\n")
                    .append("  }");
            if (i < storedMessages.size() - 1) {
                json.append(",");
            }
            json.append("\n");
        }
        json.append("]\n");

        try {
            Files.writeString(storageFile, json.toString());
        } catch (IOException e) {
            System.out.println("Could not write to " + storageFile + ": " + e.getMessage());
        }
    }

    private static String escape(String value) {
        return value.replace("\\", "\\\\").replace("\"", "\\\"");
    }

    // ---------- JSON storage: reading into the stored messages array ----------

    /**
     * Reads the JSON file back into the stored messages array and adds the
     * loaded messages' hashes and IDs to the hash and ID arrays.
     *
     * Reading is done with a small parser written for the file's shape (an
     * array of flat objects whose values are strings), following the string
     * and escape rules in the JSON specification: https://www.json.org/ and
     * RFC 8259 https://www.rfc-editor.org/rfc/rfc8259
     *
     * @return how many messages were loaded (0 if there is no file yet)
     */
    public static int loadStoredMessages() {
        if (!Files.exists(storageFile)) {
            return 0;
        }

        List<java.util.Map<String, String>> records;
        try {
            records = parseJsonObjects(Files.readString(storageFile));
        } catch (IOException | IllegalArgumentException e) {
            System.out.println("Could not read " + storageFile + ": " + e.getMessage());
            return 0;
        }

        for (Message old : storedMessages) {
            messageHashes.remove(old.messageHash);
            messageIds.remove(old.messageId);
        }
        storedMessages.clear();

        for (java.util.Map<String, String> record : records) {
            String hash = record.getOrDefault("messageHash", "");
            Message loaded = new Message(
                    record.getOrDefault("messageId", ""),
                    numberFromHash(hash),
                    record.getOrDefault("sender", "Unknown sender"),
                    record.getOrDefault("recipient", ""),
                    record.getOrDefault("message", ""));
            loaded.status = "Stored";
            storedMessages.add(loaded);
            if (!messageHashes.contains(loaded.messageHash)) {
                messageHashes.add(loaded.messageHash);
            }
            if (!messageIds.contains(loaded.messageId)) {
                messageIds.add(loaded.messageId);
            }
            // Keep numbering going after the highest loaded message number.
            messageCounter = Math.max(messageCounter, loaded.messageNumber + 1);
        }
        return storedMessages.size();
    }

    /** The hash looks like 00:0:HITONIGHT, so the message number is the middle part. */
    private static int numberFromHash(String hash) {
        String[] parts = hash.split(":");
        if (parts.length >= 2) {
            try {
                return Integer.parseInt(parts[1]);
            } catch (NumberFormatException e) {
                return 0;
            }
        }
        return 0;
    }

    private static List<java.util.Map<String, String>> parseJsonObjects(String json) {
        List<java.util.Map<String, String>> records = new ArrayList<>();
        int[] pos = {0};

        skipWhitespace(json, pos);
        expect(json, pos, '[');
        skipWhitespace(json, pos);
        if (peek(json, pos) == ']') {
            return records;
        }

        while (true) {
            skipWhitespace(json, pos);
            expect(json, pos, '{');
            java.util.Map<String, String> record = new java.util.LinkedHashMap<>();

            skipWhitespace(json, pos);
            if (peek(json, pos) != '}') {
                while (true) {
                    skipWhitespace(json, pos);
                    String key = parseJsonString(json, pos);
                    skipWhitespace(json, pos);
                    expect(json, pos, ':');
                    skipWhitespace(json, pos);
                    String value = parseJsonString(json, pos);
                    record.put(key, value);
                    skipWhitespace(json, pos);
                    if (peek(json, pos) == ',') {
                        pos[0]++;
                    } else {
                        break;
                    }
                }
            }
            skipWhitespace(json, pos);
            expect(json, pos, '}');
            records.add(record);

            skipWhitespace(json, pos);
            if (peek(json, pos) == ',') {
                pos[0]++;
            } else {
                break;
            }
        }

        skipWhitespace(json, pos);
        expect(json, pos, ']');
        return records;
    }

    private static String parseJsonString(String json, int[] pos) {
        expect(json, pos, '"');
        StringBuilder value = new StringBuilder();
        while (true) {
            if (pos[0] >= json.length()) {
                throw new IllegalArgumentException("unterminated string in JSON");
            }
            char c = json.charAt(pos[0]++);
            if (c == '"') {
                return value.toString();
            }
            if (c != '\\') {
                value.append(c);
                continue;
            }
            if (pos[0] >= json.length()) {
                throw new IllegalArgumentException("bad escape in JSON");
            }
            char escaped = json.charAt(pos[0]++);
            switch (escaped) {
                case '"': value.append('"'); break;
                case '\\': value.append('\\'); break;
                case '/': value.append('/'); break;
                case 'b': value.append('\b'); break;
                case 'f': value.append('\f'); break;
                case 'n': value.append('\n'); break;
                case 'r': value.append('\r'); break;
                case 't': value.append('\t'); break;
                case 'u':
                    if (pos[0] + 4 > json.length()) {
                        throw new IllegalArgumentException("bad unicode escape in JSON");
                    }
                    value.append((char) Integer.parseInt(json.substring(pos[0], pos[0] + 4), 16));
                    pos[0] += 4;
                    break;
                default:
                    throw new IllegalArgumentException("bad escape \\" + escaped + " in JSON");
            }
        }
    }

    private static void skipWhitespace(String json, int[] pos) {
        while (pos[0] < json.length() && Character.isWhitespace(json.charAt(pos[0]))) {
            pos[0]++;
        }
    }

    private static char peek(String json, int[] pos) {
        return pos[0] < json.length() ? json.charAt(pos[0]) : '\0';
    }

    private static void expect(String json, int[] pos, char expected) {
        if (peek(json, pos) != expected) {
            throw new IllegalArgumentException(
                    "expected '" + expected + "' at position " + pos[0] + " in JSON");
        }
        pos[0]++;
    }

    // ---------- "Stored Messages" menu operations ----------

    /** a. The sender and recipient of every stored message. */
    public static String displaySenderAndRecipient() {
        if (storedMessages.isEmpty()) {
            return "No stored messages.";
        }
        StringBuilder output = new StringBuilder();
        for (Message message : storedMessages) {
            output.append("Sender: ").append(message.sender)
                    .append(" | Recipient: ").append(message.recipient).append("\n");
        }
        return output.toString();
    }

    /** b. The longest stored message (the first one if two are the same length). */
    public static String getLongestStoredMessage() {
        if (storedMessages.isEmpty()) {
            return "No stored messages.";
        }
        Message longest = storedMessages.get(0);
        for (Message message : storedMessages) {
            if (message.messageText.length() > longest.messageText.length()) {
                longest = message;
            }
        }
        return longest.messageText;
    }

    /**
     * c. Finds a message by its ID. Searches the sent, disregarded and stored
     * arrays, because the brief's test searches for a message that was sent.
     *
     * @return the message, or null if no message has that ID
     */
    public static Message findMessageById(String id) {
        for (ArrayList<Message> array : List.of(sentMessages, disregardedMessages, storedMessages)) {
            for (Message message : array) {
                if (message.messageId.equals(id)) {
                    return message;
                }
            }
        }
        return null;
    }

    /** c. The text of the message with this ID (the menu also shows its recipient). */
    public static String searchByMessageId(String id) {
        Message found = findMessageById(id);
        if (found == null) {
            return "Message ID not found.";
        }
        return found.messageText;
    }

    /** d. The text of every sent or stored message for one recipient, in order. */
    public static ArrayList<String> searchByRecipient(String recipient) {
        ArrayList<String> results = new ArrayList<>();
        for (Message message : sentMessages) {
            if (message.recipient.equals(recipient)) {
                results.add(message.messageText);
            }
        }
        for (Message message : storedMessages) {
            if (message.recipient.equals(recipient)) {
                results.add(message.messageText);
            }
        }
        return results;
    }

    /**
     * e. Deletes a stored message using its hash. The message is removed from
     * the stored array, its hash and ID are removed from the hash and ID
     * arrays, and the JSON file is rewritten without it.
     */
    public static String deleteMessageByHash(String hash) {
        for (int i = 0; i < storedMessages.size(); i++) {
            Message message = storedMessages.get(i);
            if (message.messageHash.equals(hash)) {
                storedMessages.remove(i);
                messageHashes.remove(message.messageHash);
                messageIds.remove(message.messageId);
                writeStoredMessagesToFile();

                // The brief's expected wording leaves off the message's final full stop.
                String text = message.messageText;
                if (text.endsWith(".")) {
                    text = text.substring(0, text.length() - 1);
                }
                return "Message: \"" + text + "\" successfully deleted.";
            }
        }
        return "No stored message has the hash " + hash + ".";
    }

    /** f. A report listing the full details of every stored message. */
    public static String displayReport() {
        if (storedMessages.isEmpty()) {
            return "No stored messages.";
        }
        StringBuilder report = new StringBuilder("=== Stored Messages Report ===\n");
        for (Message message : storedMessages) {
            report.append(describe(message));
        }
        return report.toString();
    }

    private static String describe(Message message) {
        return "Message ID: " + message.messageId + "\n"
                + "Message Hash: " + message.messageHash + "\n"
                + "Sender: " + message.sender + "\n"
                + "Recipient: " + message.recipient + "\n"
                + "Message: " + message.messageText + "\n"
                + "------------------------\n";
    }

    // ---------- Array getters (copies, so callers cannot change the arrays) ----------

    public static ArrayList<String> getSentMessageTexts() {
        return textsOf(sentMessages);
    }

    public static ArrayList<String> getDisregardedMessageTexts() {
        return textsOf(disregardedMessages);
    }

    public static ArrayList<String> getStoredMessageTexts() {
        return textsOf(storedMessages);
    }

    public static ArrayList<String> getMessageHashes() {
        return new ArrayList<>(messageHashes);
    }

    public static ArrayList<String> getMessageIds() {
        return new ArrayList<>(messageIds);
    }

    private static ArrayList<String> textsOf(ArrayList<Message> messages) {
        ArrayList<String> texts = new ArrayList<>();
        for (Message message : messages) {
            texts.add(message.messageText);
        }
        return texts;
    }

    // ---------- Getters and setup ----------

    /** Sets who the messages are from (the logged-in user's cell number). */
    public static void setCurrentSender(String senderCellNumber) {
        currentSender = senderCellNumber;
    }

    public String getMessageId() {
        return messageId;
    }

    public int getMessageNumber() {
        return messageNumber;
    }

    public String getSender() {
        return sender;
    }

    public String getRecipient() {
        return recipient;
    }

    public String getMessageText() {
        return messageText;
    }

    public String getMessageHash() {
        return messageHash;
    }

    public String getStatus() {
        return status;
    }

    /** Lets the tests write to a temporary file instead of the real storedMessages.json. */
    static void setStorageFile(Path file) {
        storageFile = file;
    }

    static void resetForTesting() {
        messageCounter = 0;
        totalMessagesSent = 0;
        currentSender = "Unknown sender";
        storageFile = DEFAULT_STORAGE_FILE;
        sentMessages.clear();
        disregardedMessages.clear();
        storedMessages.clear();
        messageHashes.clear();
        messageIds.clear();
    }
}
