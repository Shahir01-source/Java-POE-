import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Part 3 unit tests. Every test starts from the five test messages in the brief:
 *
 *   1  +27834557896  "Did you get the cake?"                                    Sent
 *   2  +27838884567  "Where are you? You are late! I have asked you to be on time."  Stored
 *   3  +27834484567  "Yohoooo, I am at your gate."                               Disregard
 *   4  0838884567    "It is dinner time!"                                        Sent
 *   5  +27838884567  "Ok, I am leaving without you."                             Stored
 *
 * Message 4 is the brief's "Developer" entry: its recipient has no international
 * code, and the brief searches for it using the ID "0838884567", so it is
 * created with that ID. The other messages get fixed IDs so the tests can check
 * the hash and ID arrays.
 *
 * Note: the brief writes message 4 as "It is dinner time !" in the test data but
 * expects "It is dinner time!" as the output, so the text without the space is used.
 */
public class StoredMessagesTest {

    private static final String TEXT_1 = "Did you get the cake?";
    private static final String TEXT_2 = "Where are you? You are late! I have asked you to be on time.";
    private static final String TEXT_3 = "Yohoooo, I am at your gate.";
    private static final String TEXT_4 = "It is dinner time!";
    private static final String TEXT_5 = "Ok, I am leaving without you.";

    private static final String SENDER = "+27711111111";

    private Path storageFile;
    private Message message2;

    @BeforeEach
    public void setUp() throws IOException {
        Message.resetForTesting();
        storageFile = Files.createTempFile("storedMessagesTest", ".json");
        Message.setStorageFile(storageFile);
        Message.setCurrentSender(SENDER);

        Message message1 = Message.developerMessage("1000000001", "+27834557896", TEXT_1);
        message2 = Message.developerMessage("2000000002", "+27838884567", TEXT_2);
        Message message3 = Message.developerMessage("3000000003", "+27834484567", TEXT_3);
        Message message4 = Message.developerMessage("0838884567", "0838884567", TEXT_4);
        Message message5 = Message.developerMessage("5000000005", "+27838884567", TEXT_5);

        message1.sentMessage(1);   // Sent
        message2.sentMessage(3);   // Stored
        message3.sentMessage(2);   // Disregard
        message4.sentMessage(1);   // Sent
        message5.sentMessage(3);   // Stored
    }

    @AfterEach
    public void tearDown() throws IOException {
        Message.resetForTesting();
        Files.deleteIfExists(storageFile);
    }

    // ---------- Arrays are populated (assertEquals) ----------

    @Test
    public void testSentMessagesArrayCorrectlyPopulated() {
        assertEquals(List.of(TEXT_1, TEXT_4), Message.getSentMessageTexts());
    }

    @Test
    public void testDisregardedMessagesArrayCorrectlyPopulated() {
        assertEquals(List.of(TEXT_3), Message.getDisregardedMessageTexts());
    }

    @Test
    public void testStoredMessagesArrayCorrectlyPopulated() {
        assertEquals(List.of(TEXT_2, TEXT_5), Message.getStoredMessageTexts());
    }

    @Test
    public void testMessageHashArrayCorrectlyPopulated() {
        assertEquals(List.of("10:0:DIDCAKE", "20:1:WHERETIME", "30:2:YOHOOOOGATE",
                "08:3:ITTIME", "50:4:OKYOU"), Message.getMessageHashes());
    }

    @Test
    public void testMessageIdArrayCorrectlyPopulated() {
        assertEquals(List.of("1000000001", "2000000002", "3000000003",
                "0838884567", "5000000005"), Message.getMessageIds());
    }

    // ---------- Menu options (assertEquals) ----------

    @Test
    public void testDisplaySenderAndRecipient() {
        String expected = "Sender: " + SENDER + " | Recipient: +27838884567\n"
                + "Sender: " + SENDER + " | Recipient: +27838884567\n";
        assertEquals(expected, Message.displaySenderAndRecipient());
    }

    @Test
    public void testDisplayLongestMessage() {
        assertEquals("Where are you? You are late! I have asked you to be on time.",
                Message.getLongestStoredMessage());
    }

    @Test
    public void testSearchForMessageId() {
        assertEquals("It is dinner time!", Message.searchByMessageId("0838884567"));
    }

    @Test
    public void testSearchForMessageId_ShowsRecipientToo() {
        Message found = Message.findMessageById("0838884567");
        assertEquals("0838884567", found.getRecipient());
        assertEquals("It is dinner time!", found.getMessageText());
    }

    @Test
    public void testSearchForMessageId_NotFound() {
        assertEquals("Message ID not found.", Message.searchByMessageId("9999999999"));
    }

    @Test
    public void testSearchMessagesForRecipient() {
        ArrayList<String> expected = new ArrayList<>(List.of(
                "Where are you? You are late! I have asked you to be on time.",
                "Ok, I am leaving without you."));
        assertEquals(expected, Message.searchByRecipient("+27838884567"));
    }

    @Test
    public void testSearchMessagesForRecipient_NoMatches() {
        assertEquals(new ArrayList<String>(), Message.searchByRecipient("+27000000000"));
    }

    @Test
    public void testDeleteMessageUsingMessageHash() {
        String expected = "Message: \"Where are you? You are late! I have asked you to be on time\""
                + " successfully deleted.";
        assertEquals(expected, Message.deleteMessageByHash(message2.getMessageHash()));
    }

    @Test
    public void testDeleteRemovesMessageFromArraysAndFile() throws IOException {
        Message.deleteMessageByHash(message2.getMessageHash());

        assertEquals(List.of(TEXT_5), Message.getStoredMessageTexts());
        assertTrue(!Message.getMessageHashes().contains(message2.getMessageHash()));
        assertTrue(!Message.getMessageIds().contains("2000000002"));
        assertTrue(!Files.readString(storageFile).contains("Where are you?"));
    }

    @Test
    public void testDeleteMessage_HashNotFound() {
        assertEquals("No stored message has the hash 00:0:NOPE.",
                Message.deleteMessageByHash("00:0:NOPE"));
    }

    // ---------- Reports ----------

    @Test
    public void testDisplayReport_ListsFullDetailsOfStoredMessages() {
        String report = Message.displayReport();
        assertTrue(report.contains("Message ID: 2000000002"));
        assertTrue(report.contains("Message Hash: 20:1:WHERETIME"));
        assertTrue(report.contains("Sender: " + SENDER));
        assertTrue(report.contains("Recipient: +27838884567"));
        assertTrue(report.contains("Message: " + TEXT_2));
        assertTrue(report.contains("Message Hash: 50:4:OKYOU"));
        assertTrue(report.contains("Message: " + TEXT_5));
        assertTrue(!report.contains(TEXT_1));
    }

    @Test
    public void testDisplayReport_SentMessagesShowHashRecipientAndMessage() {
        String report = Message.printMessages();
        assertTrue(report.contains("Message Hash: 10:0:DIDCAKE"));
        assertTrue(report.contains("Recipient: +27834557896"));
        assertTrue(report.contains("Message: " + TEXT_1));
        assertTrue(report.contains("Message Hash: 08:3:ITTIME"));
        assertTrue(report.contains("Recipient: 0838884567"));
        assertTrue(report.contains("Message: " + TEXT_4));
    }

    // ---------- Reading the JSON file back into the stored array ----------

    @Test
    public void testStoredMessagesAreReadBackFromJsonFile() {
        Message.resetForTesting();
        Message.setStorageFile(storageFile);

        assertEquals(2, Message.loadStoredMessages());
        assertEquals(List.of(TEXT_2, TEXT_5), Message.getStoredMessageTexts());
        assertEquals(List.of("20:1:WHERETIME", "50:4:OKYOU"), Message.getMessageHashes());
        assertEquals(List.of("2000000002", "5000000005"), Message.getMessageIds());
        // The sender was saved in the file too, so it comes back with each message.
        String expected = "Sender: " + SENDER + " | Recipient: +27838884567\n"
                + "Sender: " + SENDER + " | Recipient: +27838884567\n";
        assertEquals(expected, Message.displaySenderAndRecipient());
    }

    @Test
    public void testLoadedMessagesCanBeSearchedAndDeleted() {
        String hash = message2.getMessageHash();
        Message.resetForTesting();
        Message.setStorageFile(storageFile);
        Message.loadStoredMessages();

        assertEquals(TEXT_5, Message.searchByMessageId("5000000005"));
        assertEquals("Message: \"Where are you? You are late! I have asked you to be on time\""
                + " successfully deleted.", Message.deleteMessageByHash(hash));
    }

    @Test
    public void testMessageWithQuotesSurvivesJsonRoundTrip() {
        String tricky = "She said \"come now\" and left \\ quickly";
        Message.resetForTesting();
        Message.setStorageFile(storageFile);
        Message stored = Message.developerMessage("7000000007", "+27820000000", tricky);
        stored.sentMessage(3);

        Message.resetForTesting();
        Message.setStorageFile(storageFile);
        assertEquals(1, Message.loadStoredMessages());
        assertEquals(List.of(tricky), Message.getStoredMessageTexts());
    }

    @Test
    public void testLoadStoredMessages_NoFileYet() throws IOException {
        Files.delete(storageFile);
        Message.resetForTesting();
        Message.setStorageFile(storageFile);
        assertEquals(0, Message.loadStoredMessages());
    }

    // ---------- Nothing stored ----------

    @Test
    public void testEmptyStoredArray() {
        Message.resetForTesting();
        assertEquals("No stored messages.", Message.displaySenderAndRecipient());
        assertEquals("No stored messages.", Message.getLongestStoredMessage());
        assertEquals("No stored messages.", Message.displayReport());
    }
}
